"""Reference-inspired dark ACMFDS dashboard built with PySide6 and MuJoCo."""
from __future__ import annotations

import math
import sys

import mujoco
import numpy as np
from PySide6.QtCore import Qt, QRect, QTimer
from PySide6.QtGui import QColor, QBrush, QFont, QImage, QPainter, QPen
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QCheckBox,
    QComboBox,
    QProgressBar,
    QPushButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from config import DESTINATION, START
from planner import MAXX, MAXY, MINX, MINY


COLORS = {
    "background": "#020d17",
    "panel": "#041826",
    "panel_inner": "#061b2a",
    "border": "#08729b",
    "border_soft": "#153d54",
    "cyan": "#32caff",
    "blue": "#2497ff",
    "green": "#15ed83",
    "orange": "#ff9e32",
    "red": "#ff494e",
    "text": "#d9efff",
    "muted": "#8db7cc",
    "grid": "#18394d",
}


class Panel(QFrame):
    """Small two-column metric card with optional inline progress bars."""

    def __init__(self, title: str, rows: list[tuple[str, str]], progress_keys: set[str] | None = None):
        super().__init__()
        self.setObjectName("panel")
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.values: dict[str, QLabel] = {}
        self.bars: dict[str, QProgressBar] = {}
        progress_keys = progress_keys or set()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 4, 8, 5)
        layout.setSpacing(2)

        title_label = QLabel(title.upper())
        title_label.setObjectName("panelTitle")
        title_label.setMinimumHeight(18)
        layout.addWidget(title_label)

        for key, value in rows:
            row = QHBoxLayout()
            row.setSpacing(5)
            left = QLabel(key)
            left.setObjectName("metricName")
            left.setMinimumWidth(108)
            right = QLabel(value)
            right.setObjectName("metricValue")
            right.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            right.setTextInteractionFlags(Qt.TextSelectableByMouse)
            row.addWidget(left, 0)
            row.addWidget(right, 1)
            layout.addLayout(row)
            self.values[key] = right

            if key in progress_keys:
                bar = QProgressBar()
                bar.setObjectName("metricBar")
                bar.setRange(0, 100)
                bar.setValue(0)
                bar.setTextVisible(False)
                bar.setFixedHeight(11)
                layout.addWidget(bar)
                self.bars[key] = bar

    def set(self, key: str, value: object) -> None:
        if key in self.values:
            self.values[key].setText(str(value))

    def set_progress(self, key: str, value: float) -> None:
        if key in self.bars:
            self.bars[key].setValue(int(max(0.0, min(100.0, value))))


class WeightPanel(QFrame):
    """Inline adaptive-weight rows matching the reference screenshot."""

    WEIGHT_COLORS = {
        "Safety": "#2497ff",
        "Energy": "#4ec8a0",
        "Time": "#ff9c47",
        "Tracking": "#8270f8",
        "Mission": "#ffc640",
    }

    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("panel")
        self.setMinimumHeight(145)
        self._bars: dict[str, QProgressBar] = {}
        self._values: dict[str, QLabel] = {}
        outer = QVBoxLayout(self)
        outer.setContentsMargins(8, 5, 8, 6)
        outer.setSpacing(3)
        title = QLabel("ADAPTIVE WEIGHTS (DATA-DRIVEN)")
        title.setObjectName("panelTitle")
        outer.addWidget(title)
        for key in ("Safety", "Energy", "Time", "Tracking", "Mission"):
            row = QHBoxLayout()
            row.setSpacing(6)
            name = QLabel(key)
            name.setMinimumWidth(64)
            name.setObjectName("metricName")
            value = QLabel("0.20")
            value.setMinimumWidth(42)
            value.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            value.setObjectName("metricValue")
            bar = QProgressBar()
            bar.setRange(0, 100)
            bar.setValue(20)
            bar.setTextVisible(False)
            bar.setFixedHeight(14)
            bar.setObjectName("weightBar")
            bar.setStyleSheet(
                "QProgressBar {background:#122d40;border:0;border-radius:3px;}"
                f"QProgressBar::chunk {{background:{self.WEIGHT_COLORS[key]};border-radius:3px;}}"
            )
            row.addWidget(name)
            row.addWidget(value)
            row.addWidget(bar, 1)
            outer.addLayout(row)
            self._values[key] = value
            self._bars[key] = bar

    def set_weights(self, weights: dict[str, float]) -> None:
        for key in self._bars:
            value = float(weights.get(key.lower(), 0.0))
            self._values[key].setText(f"{value:.2f}")
            self._bars[key].setValue(int(round(value * 100)))


class ChartFrame(QFrame):
    def __init__(self, title: str, child: QWidget, min_height: int = 180) -> None:
        super().__init__()
        self.setObjectName("panel")
        self.setMinimumHeight(min_height)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 7, 8, 7)
        layout.setSpacing(3)
        if title.strip():
            label = QLabel(title.upper())
            label.setObjectName("panelTitle")
            layout.addWidget(label)
        layout.addWidget(child, 1)


class PlotWidget(QWidget):
    """Time-series plot with explicit axes, tick values, units and margins."""

    def __init__(
        self,
        title: str,
        y_label: str,
        y_min: float,
        y_max: float,
        y_step: float,
        line_color: str,
    ) -> None:
        super().__init__()
        self.title = title
        self.y_label = y_label
        self.y_min = y_min
        self.y_max = y_max
        self.y_step = y_step
        self.line_color = QColor(line_color)
        self.times: list[float] = []
        self.values: list[float] = []
        self.setMinimumHeight(145)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def set_data(self, times: list[float], values: list[float]) -> None:
        self.times = list(times)[-610:]
        self.values = list(values)[-610:]
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802 - Qt API
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.fillRect(self.rect(), QColor("#031522"))

        width = self.width()
        height = self.height()
        left, right, top, bottom = 50, 12, 20, 30
        plot = QRect(left, top, max(10, width - left - right), max(10, height - top - bottom))

        # Six evenly spaced horizontal levels, each with a readable value.
        y_count = int(round((self.y_max - self.y_min) / self.y_step))
        font = QFont("Arial", 8)
        painter.setFont(font)
        for i in range(y_count + 1):
            value = self.y_min + i * self.y_step
            y = plot.bottom() - int(round((value - self.y_min) / (self.y_max - self.y_min) * plot.height()))
            painter.setPen(QPen(QColor(COLORS["grid"]), 1))
            painter.drawLine(plot.left(), y, plot.right(), y)
            painter.setPen(QColor("#9abacc"))
            text = f"{value:g}"
            painter.drawText(QRect(16, y - 7, left - 21, 15), Qt.AlignRight | Qt.AlignVCenter, text)

        # Expand the time axis in steps as the simulation runs. This keeps the
        # first few seconds readable instead of pinning all points to the left.
        latest_time = max(self.times) if self.times else 0.0
        x_max = max(20.0, min(120.0, math.ceil(max(latest_time, 1.0) / 20.0) * 20.0))
        x_step = 5.0 if x_max <= 20.0 else (10.0 if x_max <= 60.0 else 20.0)
        x_value = 0.0
        while x_value <= x_max + 1e-6:
            x = plot.left() + int(round(x_value / x_max * plot.width()))
            painter.setPen(QPen(QColor(COLORS["grid"]), 1))
            painter.drawLine(x, plot.top(), x, plot.bottom())
            painter.setPen(QColor("#9abacc"))
            painter.drawText(QRect(x - 18, plot.bottom() + 3, 36, 13), Qt.AlignHCenter | Qt.AlignTop, f"{x_value:g}")
            x_value += x_step

        painter.setPen(QPen(QColor("#588298"), 1))
        painter.drawLine(plot.left(), plot.top(), plot.left(), plot.bottom())
        painter.drawLine(plot.left(), plot.bottom(), plot.right(), plot.bottom())

        # Labels are placed outside the graph area so they never overlap ticks.
        painter.setPen(QColor("#d7efff"))
        painter.setFont(QFont("Arial", 9, QFont.DemiBold))
        painter.drawText(QRect(left, 0, plot.width(), 13), Qt.AlignHCenter | Qt.AlignVCenter, self.title)
        painter.setFont(QFont("Arial", 8))
        painter.drawText(QRect(plot.left(), height - 14, plot.width(), 12), Qt.AlignHCenter | Qt.AlignVCenter, "Time (s)")
        painter.save()
        painter.translate(7, plot.center().y())
        painter.rotate(-90)
        painter.drawText(QRect(int(-plot.height() / 2), -7, plot.height(), 14), Qt.AlignHCenter | Qt.AlignVCenter, self.y_label)
        painter.restore()

        # Keep points in range; this makes labels and the plotted trace consistent.
        if len(self.times) >= 2 and len(self.values) >= 2:
            points = []
            for t, value in zip(self.times, self.values):
                px = plot.left() + np.clip(float(t) / x_max, 0.0, 1.0) * plot.width()
                py = plot.bottom() - np.clip(
                    (float(value) - self.y_min) / (self.y_max - self.y_min), 0.0, 1.0
                ) * plot.height()
                points.append((int(round(px)), int(round(py))))
            painter.setClipRect(plot)
            painter.setPen(QPen(self.line_color, 2.1, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
            for a, b in zip(points, points[1:]):
                painter.drawLine(a[0], a[1], b[0], b[1])
            painter.setClipping(False)
            last_value = self.values[-1]
            painter.setPen(QColor("#e3f7ff"))
            painter.setFont(QFont("Arial", 8, QFont.Bold))
            painter.drawText(QRect(plot.right() - 60, plot.top() + 2, 57, 14), Qt.AlignRight, f"{last_value:.2f}")
        painter.end()


class TopView(QWidget):
    """XY map showing the safe route, obstacles, start, target and current drone."""

    def __init__(self, sim) -> None:
        super().__init__()
        self.sim = sim
        self.setMinimumHeight(220)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def _plot_rect(self) -> QRect:
        return QRect(54, 16, max(20, self.width() - 71), max(20, self.height() - 52))

    def world_to_screen(self, x: float, y: float) -> tuple[int, int]:
        plot = self._plot_rect()
        px = plot.left() + (float(x) - MINX) / (MAXX - MINX) * plot.width()
        py = plot.bottom() - (float(y) - MINY) / (MAXY - MINY) * plot.height()
        return int(round(px)), int(round(py))

    def paintEvent(self, event) -> None:  # noqa: N802 - Qt API
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.fillRect(self.rect(), QColor("#031522"))
        plot = self._plot_rect()

        # Grid and tick labels adapt to the expanded world bounds.
        def ticks_for(low: float, high: float) -> list[int]:
            span = high - low
            step = 4 if span >= 14 else (2 if span >= 8 else 1)
            first = int(math.ceil(low / step) * step)
            return list(range(first, int(math.floor(high / step) * step) + 1, step))

        x_ticks = ticks_for(MINX, MAXX)
        y_ticks = ticks_for(MINY, MAXY)
        for value in x_ticks:
            x, _ = self.world_to_screen(value, 0)
            p.setPen(QPen(QColor("#123247"), 1))
            p.drawLine(x, plot.top(), x, plot.bottom())
            p.setPen(QColor("#abcada"))
            p.setFont(QFont("Arial", 8))
            p.drawText(QRect(x - 14, plot.bottom() + 3, 28, 13), Qt.AlignHCenter | Qt.AlignTop, str(value))
        for value in y_ticks:
            _, y = self.world_to_screen(0, value)
            p.setPen(QPen(QColor("#123247"), 1))
            p.drawLine(plot.left(), y, plot.right(), y)
            p.setPen(QColor("#abcada"))
            p.setFont(QFont("Arial", 8))
            p.drawText(QRect(17, y - 7, 31, 14), Qt.AlignRight | Qt.AlignVCenter, str(value))

        p.setPen(QPen(QColor("#4b7790"), 1))
        p.drawRect(plot)

        # Explicit moving-hazard status badge so users can tell the dynamic
        # obstacle feature is active at a glance.
        badge = QRect(max(plot.left() + 108, plot.right() - 135), plot.top() + 5, 128, 22)
        if getattr(self.sim, "dynamic_enabled", True):
            badge_bg = QColor(91, 48, 10, 230)
            badge_fg = QColor("#ffc477")
            badge_text = f"DYNAMIC x{len(getattr(self.sim, 'dynamic_obstacles', []))} ACTIVE"
        else:
            badge_bg = QColor(44, 52, 60, 220)
            badge_fg = QColor("#abb8c1")
            badge_text = "DYNAMIC OFF"
        p.setPen(QPen(QColor("#a96a2f"), 1))
        p.setBrush(QBrush(badge_bg))
        p.drawRoundedRect(badge, 4, 4)
        p.setPen(badge_fg)
        p.setFont(QFont("Arial", 8, QFont.Bold))
        p.drawText(badge, Qt.AlignCenter, badge_text)

        # Decorative city blocks in the XY map.
        sx = plot.width() / (MAXX - MINX)
        sy = plot.height() / (MAXY - MINY)
        for bx, by, hx, hy, height in getattr(self.sim, "buildings", []):
            left, top = self.world_to_screen(bx - hx, by + hy)
            right, bottom = self.world_to_screen(bx + hx, by - hy)
            p.setPen(Qt.NoPen)
            p.setBrush(QBrush(QColor(65, 88, 111, 170)))
            p.drawRect(QRect(min(left, right), min(top, bottom), max(1, abs(right - left)), max(1, abs(bottom - top))))

        # Draw the full sweep of each moving hazard first, so motion is obvious
        # even in a paused screenshot. Orange dashed lines show the travel range.
        if getattr(self.sim, "dynamic_enabled", True):
            p.setPen(QPen(QColor("#9e5721"), 2, Qt.DashLine))
            for x1, y1, x2, y2 in getattr(self.sim, "dynamic_obstacle_tracks", []):
                a = self.world_to_screen(x1, y1)
                b = self.world_to_screen(x2, y2)
                p.drawLine(a[0], a[1], b[0], b[1])
                p.setBrush(QBrush(QColor("#ffb34e")))
                p.setPen(QPen(QColor("#ffd27f"), 1))
                p.drawEllipse(a[0] - 3, a[1] - 3, 6, 6)
                p.drawEllipse(b[0] - 3, b[1] - 3, 6, 6)

        # Static obstacles are red; dynamic hazards are larger orange/yellow
        # markers labelled D1/D2. These update continuously with the mocap bodies.
        if getattr(self.sim, "static_enabled", True):
            for ox, oy, hx, hy, height in getattr(self.sim, "static_obstacles", []):
                cx, cy = self.world_to_screen(ox, oy)
                radius_x = max(6, int(round(max(hx, hy) * sx)))
                radius_y = max(6, int(round(max(hx, hy) * sy)))
                p.setPen(QPen(QColor("#ff9ba0"), 1))
                p.setBrush(QBrush(QColor(237, 65, 73, 220)))
                p.drawEllipse(cx - radius_x, cy - radius_y, 2 * radius_x, 2 * radius_y)

        if getattr(self.sim, "dynamic_enabled", True):
            for index, (ox, oy, hx, hy, height) in enumerate(getattr(self.sim, "dynamic_obstacles", []), start=1):
                cx, cy = self.world_to_screen(ox, oy)
                radius_x = max(9, int(round((max(hx, hy) + 0.18) * sx)))
                radius_y = max(9, int(round((max(hx, hy) + 0.18) * sy)))
                # Glow / clearance halo.
                p.setPen(QPen(QColor(255, 177, 70, 180), 1.5))
                p.setBrush(QBrush(QColor(255, 150, 47, 42)))
                p.drawEllipse(cx - radius_x, cy - radius_y, 2 * radius_x, 2 * radius_y)
                # Solid orange body marker.
                body_rx = max(7, int(round(max(hx, hy) * sx)))
                body_ry = max(7, int(round(max(hx, hy) * sy)))
                p.setBrush(QBrush(QColor("#ff861c")))
                p.setPen(QPen(QColor("#fff0ae"), 2))
                p.drawEllipse(cx - body_rx, cy - body_ry, 2 * body_rx, 2 * body_ry)
                p.setPen(QColor("#351b00"))
                p.setFont(QFont("Arial", 8, QFont.Bold))
                p.drawText(QRect(cx - body_rx, cy - 6, 2 * body_rx, 12), Qt.AlignCenter, f"D{index}")

        # Show the currently selected route, not always the best-ranked route.
        ranking = getattr(self.sim, "path_ranking", [])
        if ranking:
            selected = next(
                (item for item in ranking if int(item.get("path_id", -1)) == int(getattr(self.sim, "selected_path_id", -1))),
                ranking[0],
            )
            best = selected.get("path", [])
            if len(best) >= 2:
                p.setPen(QPen(QColor("#4b788f"), 1.3, Qt.DashLine))
                coords = [self.world_to_screen(x, y) for x, y in best]
                for a, b in zip(coords, coords[1:]):
                    p.drawLine(a[0], a[1], b[0], b[1])

        active = [tuple(self.sim.pos[:2])]
        active.extend(tuple(point[:2]) for point in self.sim.waypoints[self.sim.wp_index :])
        if len(active) >= 2:
            p.setPen(QPen(QColor("#60e4ff"), 2.2, Qt.DashLine, Qt.RoundCap))
            coords = [self.world_to_screen(x, y) for x, y in active]
            for a, b in zip(coords, coords[1:]):
                p.drawLine(a[0], a[1], b[0], b[1])

        # Start and target markers.
        start_x, start_y = self.world_to_screen(START[0], START[1])
        target_x, target_y = self.world_to_screen(DESTINATION[0], DESTINATION[1])
        p.setPen(QPen(QColor("#d5edff"), 1))
        p.setBrush(QBrush(QColor("#087df5")))
        p.drawEllipse(start_x - 7, start_y - 7, 14, 14)
        p.setBrush(QBrush(QColor("#08eb7c")))
        p.setPen(QPen(QColor("#a3ffd3"), 1))
        p.drawEllipse(target_x - 8, target_y - 8, 16, 16)
        drone_x, drone_y = self.world_to_screen(self.sim.pos[0], self.sim.pos[1])
        p.setBrush(QBrush(QColor("#42d5ff")))
        p.setPen(QPen(QColor("#d7f8ff"), 1.3))
        p.drawEllipse(drone_x - 5, drone_y - 5, 10, 10)

        # Compact legend.
        # Place the legend top-left; the previous top-right position could
        # cover the moving hazards when they crossed the right half of the map.
        legend_x = plot.left() + 8
        legend_y = plot.top() + 8
        p.setPen(QPen(QColor("#28536b"), 1))
        p.setBrush(QBrush(QColor(4, 23, 37, 235)))
        p.drawRoundedRect(QRect(legend_x - 5, legend_y - 5, 99, 103), 4, 4)
        p.setFont(QFont("Arial", 8))
        p.setPen(QPen(QColor("#e0f4ff"), 1))
        p.drawText(legend_x + 4, legend_y + 7, "-- Path")
        legend_entries = [
            ("Start", "#087df5"),
            ("Target", "#08eb7c"),
            ("Static", "#ed4149"),
            ("Dynamic", "#ff962f"),
        ]
        for index, (label, color) in enumerate(legend_entries):
            yy = legend_y + 13 + index * 18
            p.setBrush(QBrush(QColor(color)))
            p.setPen(Qt.NoPen)
            p.drawEllipse(legend_x + 4, yy, 10, 10)
            p.setPen(QColor("#e0f4ff"))
            p.drawText(legend_x + 19, yy + 9, label)

        p.setPen(QColor("#d7efff"))
        p.setFont(QFont("Arial", 8))
        p.drawText(QRect(plot.left(), self.height() - 16, plot.width(), 12), Qt.AlignHCenter, "X (m)")
        p.save()
        p.translate(7, plot.center().y())
        p.rotate(-90)
        p.drawText(QRect(int(-plot.height() / 2), -6, plot.height(), 12), Qt.AlignHCenter, "Y (m)")
        p.restore()
        p.end()


class MjView(QFrame):
    """Interactive MuJoCo viewport with 360-degree camera orbit and zoom."""

    def __init__(self, sim) -> None:
        super().__init__()
        self.sim = sim
        self.setObjectName("viewport")
        self.setMinimumSize(470, 360)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)
        self.renderer = None
        self.renderer_error = ""
        try:
            # Keep requests below MuJoCo's default offscreen framebuffer dimensions.
            self.renderer = mujoco.Renderer(sim.model, height=480, width=640)
        except Exception as exc:
            self.renderer_error = str(exc)
        self.camera = mujoco.MjvCamera()
        mujoco.mjv_defaultCamera(self.camera)
        self._home_azimuth = 138.0
        self._home_elevation = -32.0
        self._home_distance = 25.5
        self._last_mouse_pos = None
        self.camera.lookat[:] = [6.0, 5.0, 0.75]
        self.camera.distance = self._home_distance
        self.camera.azimuth = self._home_azimuth
        self.camera.elevation = self._home_elevation
        self.orbit_timer = QTimer(self)
        self.orbit_timer.setInterval(40)
        self.orbit_timer.timeout.connect(self._advance_orbit)

    def set_auto_orbit(self, enabled: bool) -> None:
        """Start/stop continuous azimuth rotation across the complete 360 degrees."""
        if enabled:
            self.orbit_timer.start()
        else:
            self.orbit_timer.stop()
        self.update()

    def is_auto_orbiting(self) -> bool:
        return self.orbit_timer.isActive()

    def _advance_orbit(self) -> None:
        self.camera.azimuth = (float(self.camera.azimuth) + 1.5) % 360.0
        self.update()

    def set_camera_preset(self, preset: str) -> None:
        """Set one of the named camera viewpoints while keeping the arena centered."""
        self.camera.lookat[:] = [6.0, 5.0, 0.75]
        if preset == "top":
            self.camera.azimuth = 90.0
            self.camera.elevation = -85.0
            self.camera.distance = 27.5
        elif preset == "side":
            self.camera.azimuth = 90.0
            self.camera.elevation = -12.0
            self.camera.distance = 25.5
        else:
            self.camera.azimuth = self._home_azimuth
            self.camera.elevation = self._home_elevation
            self.camera.distance = self._home_distance
        self.update()

    def mousePressEvent(self, event) -> None:  # noqa: N802 - Qt API
        if event.button() == Qt.LeftButton:
            self._last_mouse_pos = event.position().toPoint()
            self.setCursor(Qt.ClosedHandCursor)
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:  # noqa: N802 - Qt API
        if self._last_mouse_pos is not None and (event.buttons() & Qt.LeftButton):
            current = event.position().toPoint()
            delta = current - self._last_mouse_pos
            self._last_mouse_pos = current
            self.camera.azimuth = (float(self.camera.azimuth) + float(delta.x()) * 0.65) % 360.0
            self.camera.elevation = float(np.clip(self.camera.elevation - float(delta.y()) * 0.42, -88.0, -5.0))
            self.update()
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802 - Qt API
        if event.button() == Qt.LeftButton:
            self._last_mouse_pos = None
            self.setCursor(Qt.ArrowCursor)
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def wheelEvent(self, event) -> None:  # noqa: N802 - Qt API
        steps = float(event.angleDelta().y()) / 120.0
        self.camera.distance = float(np.clip(self.camera.distance * math.exp(-0.12 * steps), 7.5, 48.0))
        self.update()
        event.accept()

    def paintEvent(self, event) -> None:  # noqa: N802 - Qt API
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        try:
            if self.renderer is None:
                raise RuntimeError(self.renderer_error or "MuJoCo renderer could not be initialized")
            self.renderer.update_scene(self.sim.data, camera=self.camera)
            rgb = self.renderer.render()
            h, w, _ = rgb.shape
            image = QImage(rgb.data, w, h, 3 * w, QImage.Format_RGB888).copy()
            image = image.scaled(self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            painter.fillRect(self.rect(), QColor("#031522"))
            painter.drawImage((self.width() - image.width()) // 2, (self.height() - image.height()) // 2, image)

            # Camera control legend layered over the actual MuJoCo render.
            painter.setPen(QPen(QColor("#2c6987"), 1))
            painter.setBrush(QBrush(QColor(3, 22, 36, 225)))
            painter.drawRoundedRect(QRect(12, 12, 204, 122), 7, 7)
            painter.setFont(QFont("Arial", 9, QFont.DemiBold))
            painter.setPen(QColor("#49d2ff"))
            painter.drawText(22, 29, "3D FLIGHT VIEW | 360° CAMERA")
            painter.setFont(QFont("Arial", 8))
            for index, text in enumerate(("Drag left mouse = orbit", "Scroll = zoom in/out", "AUTO 360° = continuous rotation")):
                painter.setPen(QColor("#e4f5ff"))
                painter.drawText(22, 49 + index * 16, text)
            painter.setPen(QColor("#bdddea"))
            painter.drawText(22, 111, f"Azimuth {self.camera.azimuth % 360:.0f}°  |  Elevation {self.camera.elevation:.0f}°")
        except Exception as exc:  # Keep the rest of the UI usable if GL fails.
            painter.fillRect(self.rect(), QColor("#031522"))
            painter.setPen(QColor("#ffcc73"))
            painter.drawText(20, 32, "3D renderer error")
            painter.setPen(QColor("#d9efff"))
            painter.drawText(QRect(20, 43, max(200, self.width() - 40), 110), Qt.TextWordWrap, str(exc)[:300])
        painter.end()

    def close_renderer(self) -> None:
        self.orbit_timer.stop()
        try:
            if self.renderer is not None:
                self.renderer.close()
        except Exception:
            pass


class Dashboard(QWidget):
    def __init__(self, sim) -> None:
        super().__init__()
        self.sim = sim
        self.setObjectName("dashboardRoot")
        self.setWindowTitle("ACMFDS | Autonomous Quadrotor Simulation")
        self.resize(1536, 940)
        self.setMinimumSize(1180, 760)
        self.setStyleSheet("""
            QWidget { background: transparent; color: #d9efff; font-family: Arial; font-size: 12px; }
            #dashboardRoot { background: #020d17; }
            #panel, #viewport { background: #041826; border: 1px solid #08729b; border-radius: 7px; }
            #routeOptionsBar { background: #041826; border: 1px solid #08729b; border-radius: 6px; }
            QComboBox { background: #061b2a; color: #d9efff; border: 1px solid #1f6684; border-radius: 4px; padding: 4px 7px; }
            QComboBox QAbstractItemView { background: #061b2a; color: #d9efff; selection-background-color: #0b5573; }
            QCheckBox { color: #d9efff; spacing: 5px; }
            QCheckBox::indicator { width: 14px; height: 14px; }
            QCheckBox::indicator:unchecked { background: #061b2a; border: 1px solid #33718a; border-radius: 3px; }
            QCheckBox::indicator:checked { background: #18c889; border: 1px solid #18c889; border-radius: 3px; }
            #panelTitle { color: #45caff; font-size: 13px; font-weight: bold; padding-bottom: 4px;
                          border-bottom: 1px solid #153d54; }
            #metricName { color: #d3e9f5; }
            #metricValue { color: #f2f9ff; }
            QProgressBar#metricBar { background: #142e41; border: 0; border-radius: 3px; }
            QProgressBar#metricBar::chunk { background: #21c889; border-radius: 3px; }
            QPushButton { background: #06263a; border: 1px solid #08729b; border-radius: 5px;
                          color: #d9efff; padding: 6px 12px; font-weight: bold; }
            QPushButton:hover { background: #0b3952; }
        """)

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 8, 10, 7)
        root.setSpacing(8)

        # Header bar.
        header = QHBoxLayout()
        header.setSpacing(12)
        title_box = QVBoxLayout()
        title_box.setSpacing(1)
        title = QLabel("ACMFDS  |  AUTONOMOUS QUADROTOR SIMULATION")
        title.setStyleSheet("font-size:23px;font-weight:800;color:#dceeff;letter-spacing:0.5px;")
        subtitle = QLabel("Data-Driven Decision Making   |   Obstacle Avoidance   |   Safe & Efficient Navigation")
        subtitle.setStyleSheet("font-size:14px;color:#48c9ff;")
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        header.addLayout(title_box, 1)

        self.live_badge = QLabel("●  REAL-TIME MuJoCo PHYSICS")
        self.live_badge.setAlignment(Qt.AlignCenter)
        self.live_badge.setStyleSheet("color:#11f18a;border:1px solid #087d60;border-radius:7px;padding:8px 12px;font-weight:bold;")
        header.addWidget(self.live_badge)
        self.clock = QLabel("Sim Time: 0.0 s")
        self.clock.setAlignment(Qt.AlignCenter)
        self.clock.setStyleSheet("color:#d7efff;border:1px solid #075d80;border-radius:6px;padding:8px 12px;")
        header.addWidget(self.clock)
        root.addLayout(header)
        line = QFrame()
        line.setFixedHeight(1)
        line.setStyleSheet("background:#08729b;border:0;")
        root.addWidget(line)

        # Main split: the left telemetry column spans both upper and graph areas.
        main = QHBoxLayout()
        main.setSpacing(9)
        left = QVBoxLayout()
        left.setSpacing(8)
        left.setContentsMargins(0, 0, 0, 0)

        self.status = Panel(
            "Simulation Status",
            [("Time", "0.0 s"), ("Decision", "FORWARD"), ("Context", "CLEAR"), ("Mode", "NAVIGATING"), ("Simulation", "RUNNING")],
        )
        self.state = Panel(
            "Quadrotor State",
            [
                ("Position", "[0.00, 0.00, 2.00] m"),
                ("Velocity", "[0.00, 0.00, 0.00] m/s"),
                ("Speed", "0.00 m/s"),
                ("Altitude", "2.00 m"),
            ],
        )
        self.mission = Panel(
            "Mission Progress",
            [("Target", str(tuple(round(v, 2) for v in DESTINATION)) + " m"), ("Distance", "0.00 m"), ("Progress", "0.0 %"), ("Waypoint", "1 / 1")],
            progress_keys={"Progress"},
        )
        self.safety = Panel(
            "Safety & Risk",
            [("Nearest obstacle", "0.00 m"), ("Risk level", "LOW"), ("Obstacle risk", "0.00"), ("Status", "SAFE")],
        )
        self.energy = Panel("Energy", [("Battery", "100.0 %")], progress_keys={"Battery"})
        self.controls = Panel(
            "Control Outputs",
            [("Force X", "0.00 N"), ("Force Y", "0.00 N"), ("Thrust Z", "11.77 N"), ("Control magnitude", "11.77 N")],
        )
        for panel in (self.status, self.state, self.mission, self.safety, self.energy, self.controls):
            left.addWidget(panel)
        left.addStretch(1)
        left_widget = QWidget()
        left_widget.setLayout(left)
        left_widget.setFixedWidth(316)
        main.addWidget(left_widget)

        # Main right-side content: 3D flight view above three readable graphs.
        content = QVBoxLayout()
        content.setSpacing(8)
        top_row = QHBoxLayout()
        top_row.setSpacing(9)
        self.view = MjView(self.sim)
        view_stack = QVBoxLayout()
        view_stack.setContentsMargins(0, 0, 0, 0)
        view_stack.setSpacing(6)
        camera_bar = QHBoxLayout()
        camera_bar.setSpacing(6)
        camera_help = QLabel("CAMERA: drag to orbit · scroll to zoom")
        camera_help.setStyleSheet("color:#8db7cc;font-size:10px;")
        camera_bar.addWidget(camera_help, 1)
        self.orbit_button = QPushButton("AUTO 360° ORBIT")
        self.orbit_button.setToolTip("Continuously rotate the camera through a full 360-degree orbit.")
        self.orbit_button.clicked.connect(self.toggle_camera_orbit)
        camera_bar.addWidget(self.orbit_button)
        home_camera_button = QPushButton("OVERVIEW")
        home_camera_button.clicked.connect(lambda: self.set_camera_preset("home"))
        camera_bar.addWidget(home_camera_button)
        top_camera_button = QPushButton("TOP")
        top_camera_button.clicked.connect(lambda: self.set_camera_preset("top"))
        camera_bar.addWidget(top_camera_button)
        side_camera_button = QPushButton("SIDE")
        side_camera_button.clicked.connect(lambda: self.set_camera_preset("side"))
        camera_bar.addWidget(side_camera_button)
        view_stack.addLayout(camera_bar)
        view_stack.addWidget(self.view, 1)
        view_widget = QWidget()
        view_widget.setLayout(view_stack)
        top_row.addWidget(view_widget, 2.15)

        sidebar = QVBoxLayout()
        sidebar.setSpacing(8)
        self.top_view = TopView(self.sim)
        sidebar.addWidget(ChartFrame("Top View | XY Plane", self.top_view, min_height=225), 5)
        self.weight_panel = WeightPanel()
        sidebar.addWidget(self.weight_panel, 3)
        self.objective = Panel(
            "Objective & Phase",
            [
                ("Goal", "REACH TARGET SAFELY"),
                ("Flight phase", "NAVIGATING"),
                ("Path profile", "BALANCED"),
                ("Route rank", "#1 / 1"),
            ],
        )
        sidebar.addWidget(self.objective, 2)
        top_row.addLayout(sidebar, 1)
        content.addLayout(top_row, 6)

        # Interactive path-profile and obstacle controls.
        self.route_options_bar = QFrame()
        self.route_options_bar.setObjectName("routeOptionsBar")
        options_layout = QHBoxLayout(self.route_options_bar)
        options_layout.setContentsMargins(9, 5, 9, 5)
        options_layout.setSpacing(8)
        route_label = QLabel("PATH PROFILE")
        route_label.setObjectName("metricName")
        options_layout.addWidget(route_label)
        self.route_combo = QComboBox()
        self.route_combo.setMinimumWidth(220)
        self.route_combo.setMaximumWidth(310)
        self.route_combo.setToolTip("Choose a candidate route profile. Applying it replans from the current drone position.")
        options_layout.addWidget(self.route_combo)
        self.apply_route_button = QPushButton("USE ROUTE")
        self.apply_route_button.clicked.connect(self.apply_selected_route)
        options_layout.addWidget(self.apply_route_button)
        self.static_toggle = QCheckBox("Static obstacles")
        self.static_toggle.setChecked(bool(getattr(self.sim, "static_enabled", True)))
        self.dynamic_toggle = QCheckBox("Dynamic obstacles")
        self.dynamic_toggle.setChecked(bool(getattr(self.sim, "dynamic_enabled", True)))
        options_layout.addWidget(self.static_toggle)
        options_layout.addWidget(self.dynamic_toggle)
        self.replan_button = QPushButton("REPLAN")
        self.replan_button.clicked.connect(self.manual_replan)
        options_layout.addWidget(self.replan_button)
        options_layout.addStretch(1)
        self.static_toggle.toggled.connect(self.obstacle_options_changed)
        self.dynamic_toggle.toggled.connect(self.obstacle_options_changed)
        self._route_options_signature = None
        self.refresh_route_options(force=True)
        content.addWidget(self.route_options_bar)

        graph_row = QHBoxLayout()
        graph_row.setSpacing(9)
        self.distance_plot = PlotWidget("Distance to Target (m)", "Distance (m)", 0.0, 20.0, 4.0, "#23caff")
        self.battery_plot = PlotWidget("Battery Level (%)", "Battery (%)", 0.0, 100.0, 20.0, "#19ef66")
        self.speed_plot = PlotWidget("Speed (m/s)", "Speed (m/s)", 0.0, 3.0, 0.5, "#ff9e32")
        graph_row.addWidget(ChartFrame("", self.distance_plot, min_height=165), 1)
        graph_row.addWidget(ChartFrame("", self.battery_plot, min_height=165), 1)
        graph_row.addWidget(ChartFrame("", self.speed_plot, min_height=165), 1)
        content.addLayout(graph_row, 2.4)
        main.addLayout(content, 1)
        root.addLayout(main, 1)

        footer = QHBoxLayout()
        footer.setSpacing(8)
        footer_label = QLabel("ACMFDS - Autonomous Quadrotor Simulation   |   Data-Driven Models for Safe and Efficient Navigation")
        footer_label.setStyleSheet("color:#b2d5e8;font-size:11px;")
        footer.addWidget(footer_label, 1)
        self.gps_note = QLabel("GPS SIM: waiting for telemetry")
        self.gps_note.setStyleSheet("color:#75b7d4;font-size:10px;")
        footer.addWidget(self.gps_note)
        self.restart_button = QPushButton("RESTART MISSION ↻")
        self.restart_button.setToolTip("After reaching the destination, press this to return to the blue start marker and run the mission again.")
        self.restart_button.clicked.connect(self.reset_simulation)
        footer.addWidget(self.restart_button)
        tech = QLabel("Built with MuJoCo  |  PySide6  |  Python")
        tech.setStyleSheet("color:#b2d5e8;font-size:11px;")
        footer.addWidget(tech)
        root.addLayout(footer)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(16)
        self.update_display()

    def toggle_camera_orbit(self) -> None:
        enabled = not self.view.is_auto_orbiting()
        self.view.set_auto_orbit(enabled)
        self.orbit_button.setText("STOP 360° ORBIT" if enabled else "AUTO 360° ORBIT")

    def set_camera_preset(self, preset: str) -> None:
        self.view.set_camera_preset(preset)
        if self.view.is_auto_orbiting():
            # Keep orbiting from the newly chosen preset without a second click.
            self.orbit_button.setText("STOP 360° ORBIT")
        else:
            self.orbit_button.setText("AUTO 360° ORBIT")

    def reset_simulation(self) -> None:
        """Restart the mission at the blue START marker."""
        self.sim.reset()
        self.restart_button.setText("RESTART MISSION ↻")
        self.refresh_route_options(force=True)
        self.update_display()

    def refresh_route_options(self, force: bool = False) -> None:
        ranking = list(getattr(self.sim, "path_ranking", []))
        signature = tuple(
            (int(item.get("path_id", -1)), str(item.get("profile", "Route")), round(float(item.get("score", 0.0)), 3))
            for item in ranking
        )
        if not force and signature == self._route_options_signature:
            return
        current_id = int(getattr(self.sim, "selected_path_id", 1))
        self.route_combo.blockSignals(True)
        self.route_combo.clear()
        selected_index = 0
        for index, item in enumerate(ranking):
            path_id = int(item.get("path_id", index + 1))
            label = (
                f"#{item.get('rank', index + 1)} {item.get('profile', 'ROUTE')}  |  "
                f"{float(item.get('length', 0.0)):.1f} m  |  score {float(item.get('score', 0.0)):.2f}"
            )
            self.route_combo.addItem(label, path_id)
            if path_id == current_id:
                selected_index = index
        if self.route_combo.count():
            self.route_combo.setCurrentIndex(selected_index)
        self.route_combo.blockSignals(False)
        self._route_options_signature = signature

    def apply_selected_route(self) -> None:
        path_id = self.route_combo.currentData()
        if path_id is None:
            return
        if self.sim.select_route_by_id(int(path_id)):
            self.update_display()
            self.refresh_route_options(force=True)

    def manual_replan(self) -> None:
        self.sim.replan(reason="MANUAL REPLAN")
        self.refresh_route_options(force=True)
        self.update_display()

    def obstacle_options_changed(self, _checked: bool = False) -> None:
        self.sim.set_obstacle_modes(
            static_enabled=self.static_toggle.isChecked(),
            dynamic_enabled=self.dynamic_toggle.isChecked(),
        )
        self.refresh_route_options(force=True)
        self.update_display()

    def tick(self) -> None:
        if self.sim.running:
            self.sim.step()
        self.update_display()

    def update_display(self) -> None:
        p = np.asarray(self.sim.pos, dtype=float)
        v = np.asarray(self.sim.vel, dtype=float)
        distance = float(self.sim.distance_to_target)
        progress = float(self.sim.mission_progress)
        nearest = float(self.sim.nearest_obstacle)
        risk = float(self.sim.risk)
        waypoint_count = len(self.sim.waypoints)

        self.clock.setText(f"Sim Time: {self.sim.sim_time:.1f} s")
        self.status.set("Time", f"{self.sim.sim_time:.1f} s")
        self.status.set("Decision", getattr(self.sim, "decision", "FORWARD"))
        self.status.set("Context", self.sim.context)
        self.status.set("Mode", self.sim.phase)
        self.status.set("Simulation", self.sim.status)

        self.state.set("Position", f"[{p[0]:.2f}, {p[1]:.2f}, {p[2]:.2f}] m")
        self.state.set("Velocity", f"[{v[0]:.2f}, {v[1]:.2f}, {v[2]:.2f}] m/s")
        self.state.set("Speed", f"{float(np.linalg.norm(v)):.2f} m/s")
        self.state.set("Altitude", f"{p[2]:.2f} m")
        self.gps_note.setText(
            f"GPS SIM  {self.sim.gps_latitude:.6f}°, {self.sim.gps_longitude:.6f}°  |  Alt {self.sim.gps_altitude:.2f} m"
        )

        self.mission.set("Distance", f"{distance:.2f} m")
        self.mission.set("Progress", f"{progress:.1f} %")
        self.mission.set_progress("Progress", progress)
        self.mission.set("Waypoint", f"{min(self.sim.wp_index + 1, waypoint_count)} / {waypoint_count}")

        if risk >= 0.65:
            risk_level, safety_status = "HIGH", "CAUTION"
        elif risk >= 0.35:
            risk_level, safety_status = "MEDIUM", "MONITOR"
        else:
            risk_level, safety_status = "LOW", "SAFE"
        self.safety.set("Nearest obstacle", f"{nearest:.2f} m")
        self.safety.set("Risk level", risk_level)
        self.safety.set("Obstacle risk", f"{risk:.2f}")
        self.safety.set("Status", safety_status if self.sim.status == "RUNNING" else self.sim.status)

        self.energy.set("Battery", f"{self.sim.battery:.1f} %")
        self.energy.set_progress("Battery", self.sim.battery)
        self.controls.set("Force X", f"{self.sim.force_x:.2f} N")
        self.controls.set("Force Y", f"{self.sim.force_y:.2f} N")
        self.controls.set("Thrust Z", f"{self.sim.thrust_z:.2f} N")
        self.controls.set("Control magnitude", f"{self.sim.control_magnitude:.2f} N")

        self.weight_panel.set_weights(self.sim.weights)
        self.objective.set("Flight phase", self.sim.phase)
        self.objective.set("Path profile", getattr(self.sim, "selected_path_profile", "BALANCED"))
        self.objective.set("Route rank", f"#{self.sim.selected_path_rank} / {len(self.sim.path_ranking)}")
        if self.sim.status == "MISSION COMPLETE":
            self.restart_button.setText("START AGAIN ↻")
        elif self.sim.status == "LOW BATTERY":
            self.restart_button.setText("RESTART MISSION ↻")
        else:
            self.restart_button.setText("RESTART MISSION ↻")
        self.apply_route_button.setEnabled(bool(self.sim.path_ranking) and self.sim.running)
        self.replan_button.setEnabled(self.sim.running)
        self.refresh_route_options()

        self.distance_plot.set_data(self.sim.history_time, self.sim.distance_history)
        self.battery_plot.set_data(self.sim.history_time, self.sim.battery_history)
        self.speed_plot.set_data(self.sim.history_time, self.sim.speed_history)
        self.view.update()
        self.top_view.update()

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt API
        self.timer.stop()
        self.view.close_renderer()
        event.accept()


def run(sim) -> int:
    app = QApplication.instance() or QApplication(sys.argv)
    window = Dashboard(sim)
    window.showMaximized()
    return app.exec()
