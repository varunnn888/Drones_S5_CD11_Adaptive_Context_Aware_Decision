# ACMFDS — Autonomous Quadrotor Simulation

A reference-inspired PySide6 dashboard for a MuJoCo-backed quadrotor demo with a larger arena and a fully orbitable 3D camera. The project includes local-world coordinates, simulated GPS telemetry, adaptive risk/weights, candidate route planning, static hazards, and moving dynamic hazards.

## What's included

- **Restart mission:** When the drone reaches the destination, the footer button changes to **START AGAIN ↻**. Press it to reset the quadrotor to the blue start marker, reset battery/history/time, and run the mission again.
- **Route profile options:** The `PATH PROFILE` dropdown lists available candidate routes with profile name, length, and score. Select one and press **USE ROUTE** to plan that profile from the drone's current position to the destination.
- **Static obstacles:** Red cylinders are fixed. The **Static obstacles** checkbox enables/disables their collision participation and includes/excludes them from route planning.
- **Dynamic obstacles:** Orange cylinders move along repeatable paths. The **Dynamic obstacles** checkbox enables/disables them; while enabled, the simulation periodically replans to account for their moving positions.
- **Manual replan:** Press **REPLAN** to rank routes against the currently enabled obstacles.
- **360-degree view:** Click **AUTO 360° ORBIT** for continuous camera rotation; drag with the left mouse button to orbit manually, scroll to zoom, and use **OVERVIEW**, **TOP**, or **SIDE** for camera presets.
- **Larger arena:** The environment is expanded to about 16.5 m × 14.5 m, with the target moved to (12, 10, 2) m and hazards/buildings spread out to give the drone more room to navigate.
- **Route menu:** Static+dynamic is the default; switching either checkbox filters the planning obstacles and refreshes available route profiles.
- **Graphs and GPS:** Time-series graphs show units and labelled axes. GPS is simulated by converting local X/Y coordinates to latitude/longitude using the origin in `config.py`; it is not hardware GPS data.

## Run on macOS (Apple Silicon)

1. Extract the ZIP and open this folder in VS Code.
2. Open the terminal in this folder and run:

```bash
bash run_mac.sh
```

The launcher uses Python 3.12 when available (otherwise `python3`), creates this folder's `.venv` on first run, installs `requirements.txt`, and launches the dashboard. Package installation requires an internet connection on the first run. The next time, run `bash run_mac.sh` again; it reuses the environment.

If the dashboard fails, run the following and send the full output for troubleshooting:

```bash
source .venv/bin/activate
python app.py
```

## Main files

- `app.py` — application entry point
- `simulation.py` — MuJoCo world, quadrotor controller, GPS telemetry, static/dynamic hazards, reset and replanning
- `planner.py` — collision-aware A* route families and route evaluation
- `dashboard.py` — PySide6 UI, route selector, obstacle toggles, restart button, XY map and graphs
- `data_model.py` — data-driven risk prediction and adaptive objective weights
- `config.py` — start/destination, simulation rate and simulated GPS origin

## Note

This is a simulation demo, not a real-flight control system. Dynamic obstacle motion and GPS telemetry are simulated. Validate the project in your local MuJoCo/PySide6 environment before relying on the GUI output.
